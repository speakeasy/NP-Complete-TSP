var searchData=
[
  ['coordpair',['CoordPair',['../namespaceModel_1_1CoordPair.html',1,'Model']]]
];
